
# Installing Rustlings

We have a customised version of rustlings

1. Make sure you have rust installed 
2. In this directory run

`cargo install --force --path .`



## Doing exercises

Run


`rustlings homework n`
Where n is the number of the homework you are doing, i.e.

`rustlings homework 5` 



