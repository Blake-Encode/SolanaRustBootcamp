// fake_exercise

fn main() {

}
