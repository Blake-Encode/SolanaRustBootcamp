mod move_semantics1;
mod move_semantics2;
mod move_semantics3;
mod move_semantics4;
mod move_semantics5;
mod move_semantics6;
