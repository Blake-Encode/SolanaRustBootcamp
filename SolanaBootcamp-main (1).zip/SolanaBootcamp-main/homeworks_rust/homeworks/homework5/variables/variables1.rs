// variables1.rs
// Make me compile!
// Execute the command `rustlings hint variables1` if you want a hint :)

// I AM NOT DONE

fn main() {
    y = 5;
    println!("y has the value {}", y);
}
