// variables4.rs
// Make me compile! Execute the command `rustlings hint variables4` if you want a hint :)

// I AM NOT DONE

fn main() {
    let x = 3;
    println!("Number {}", x);
    x = 5; // don't change this line
    println!("Number {}", x);
}