// variables3.rs
// Make me compile! Execute the command `rustlings hint variables3` if you want a hint :)

// I AM NOT DONE

fn main() {
    let x: i32;
    println!("Number {}", x);
}