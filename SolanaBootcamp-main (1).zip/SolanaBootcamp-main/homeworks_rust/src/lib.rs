#[cfg(feature = "exercises")]
#[path = "../exercises/mod.rs"]
mod exercises;
